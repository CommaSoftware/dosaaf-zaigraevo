<?php get_header(); ?>

<?php get_template_part( 'main-banner' ); ?>
<?php get_template_part( 'courses' ); ?>
<?php get_template_part( 'teachers' ); ?>
<?php get_template_part( 'about-us' ); ?>
<?php get_template_part( 'contacts' ); ?>

<?php get_footer(); ?>